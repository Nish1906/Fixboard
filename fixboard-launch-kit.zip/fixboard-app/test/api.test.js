'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), assert = require('node:assert/strict');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'fb-'));
process.env.DEV_EXPOSE_CODE = '1';
process.env.FOUNDER_EMAIL = 'founder@test.example';
const { server } = require('../server.js');
let base;
class C { // tiny client with cookie jar
  constructor() { this.cookie = ''; }
  async call(method, url, body, headers) {
    const r = await fetch(base + url, { method, headers: Object.assign({ 'Content-Type': 'application/json', 'X-Requested-With': 'fixboard', Cookie: this.cookie }, headers || {}), body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {} return { s: r.status, j };
  }
  async signup(email, extra) { const a = await this.call('POST', '/api/auth/start', Object.assign({ email }, extra)); assert.equal(a.s, 200, JSON.stringify(a.j)); const v = await this.call('POST', '/api/auth/verify', { email, code: a.j.devCode }); assert.equal(v.s, 200, JSON.stringify(v.j)); return v.j; }
}
let pass = 0; const t = async (n, f) => { try { await f(); pass++; console.log('ok  ' + n); } catch (e) { console.log('FAIL ' + n + '\n   ' + e.message); process.exitCode = 1; } };
(async () => {
  await new Promise(r => server.listen(0, r)); base = 'http://127.0.0.1:' + server.address().port;
  const founder = new C(), ind = new C(), ind2 = new C(), stu = new C(), stu2 = new C(), odd = new C(), anon = new C();
  await t('health + public info', async () => { assert.equal((await fetch(base + '/healthz')).status, 200); const r = await anon.call('GET', '/api/public'); assert.equal(r.s, 200); });
  await t('anonymous cannot read board/people', async () => { for (const u of ['/api/board', '/api/people', '/api/leagues', '/api/staff/overview']) assert.equal((await anon.call('GET', u)).s, 401); });
  await t('writes without CSRF header are blocked', async () => { const r = await fetch(base + '/api/auth/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"email":"a@b.co"}' }); assert.equal(r.status, 403); });
  await t('personal email rejected for industry; .edu rejected for industry', async () => {
    assert.equal((await anon.call('POST', '/api/auth/start', { email: 'x@gmail.com', kind: 'industry', name: 'X Y', org: 'Z Co' })).s, 400);
    assert.equal((await anon.call('POST', '/api/auth/start', { email: 'x@uni.edu', kind: 'industry', name: 'X Y', org: 'Z Co' })).s, 400);
    assert.equal((await anon.call('POST', '/api/auth/start', { email: 'x@gmail.com', kind: 'student', name: 'X Y', org: 'School' })).s, 400);
  });
  await t('wrong code is refused; lockout after 5', async () => {
    const e = 'lock@acme-test.com'; await anon.call('POST', '/api/auth/start', { email: e, kind: 'industry', name: 'Lock Out', org: 'Acme' });
    for (let i = 0; i < 5; i++) assert.equal((await anon.call('POST', '/api/auth/verify', { email: e, code: '000000' })).s, 400);
    assert.equal((await anon.call('POST', '/api/auth/verify', { email: e, code: '000000' })).s, 429);
  });
  await t('founder becomes owner', async () => { await founder.signup('founder@test.example'); const m = await founder.call('GET', '/api/me'); assert.equal(m.j.user.staffRole, 'owner'); assert.equal(m.j.user.name, 'Nishant Parekh'); });
  await t('unknown company domain goes to review; known after trust', async () => {
    const v = await ind.signup('pat@acme-test.com', { kind: 'industry', name: 'Pat Lee', org: 'Acme', title: 'Logistics Manager' }); assert.equal(v.status, 'pending_review');
    assert.equal((await ind.call('GET', '/api/board')).s, 403);
    const q = await founder.call('GET', '/api/staff/queue'); const row = q.j.queue.find(x => x.email === 'pat@acme-test.com'); assert.ok(row);
    assert.equal((await founder.call('POST', '/api/staff/queue/' + row.id, { decision: 'approve', trustDomain: true })).s, 200);
    assert.equal((await ind.call('GET', '/api/board')).s, 200);
    const v2 = await ind2.signup('sam@acme-test.com', { kind: 'industry', name: 'Sam Roe', org: 'Acme', title: 'Planner' }); assert.equal(v2.status, 'active');
  });
  await t('.edu student is active immediately', async () => { const v = await stu.signup('ana@pitt-test.edu', { kind: 'student', name: 'Ana Diaz', org: 'Pitt', title: 'MS SCM' }); assert.equal(v.status, 'active'); await stu2.signup('bo@pitt-test.edu', { kind: 'student', name: 'Bo Chen', org: 'Pitt' }); });
  let pid, sid;
  await t('only industry can post; students cannot', async () => {
    assert.equal((await stu.call('POST', '/api/problems', { title: 'Safety stock is wrong', body: 'Our safety stock numbers do not match reality at all. Please help us.' })).s, 403);
    const r = await ind.call('POST', '/api/problems', { title: 'Safety stock is wrong', body: 'Our safety stock numbers do not match reality at all. Please help us.', tags: ['Inventory', 'Bogus'] }); assert.equal(r.s, 200); pid = r.j.id;
  });
  await t('student posts solution; own/same-org rating blocked; others can rate', async () => {
    const r = await stu.call('POST', '/api/problems/' + pid + '/solutions', { body: 'Recalculate with service level and lead time variability, then review monthly.' }); assert.equal(r.s, 200); sid = r.j.id;
    assert.equal((await stu.call('PUT', '/api/solutions/' + sid + '/rating', { stars: 5 })).s, 403);
    assert.equal((await stu2.call('PUT', '/api/solutions/' + sid + '/rating', { stars: 5 })).s, 403, 'same school blocked');
    assert.equal((await ind.call('PUT', '/api/solutions/' + sid + '/rating', { stars: 5 })).s, 200);
    assert.equal((await ind2.call('PUT', '/api/solutions/' + sid + '/rating', { stars: 4 })).s, 200);
  });
  await t('points, accept, only poster accepts, league up', async () => {
    assert.equal((await ind2.call('POST', '/api/solutions/' + sid + '/accept', {})).s, 403);
    const a = await ind.call('POST', '/api/solutions/' + sid + '/accept', {}); assert.equal(a.s, 200);
    const l = await stu.call('GET', '/api/leagues'); const me = l.j.members.find(m => m.name === 'Ana Diaz'); assert.equal(me.points, 5 + 4 + 10); assert.equal(me.league.name, 'Silver');
  });
  await t('intro request hides email until accepted', async () => {
    const people = await stu.call('GET', '/api/people'); const pat = people.j.people.find(p => p.name === 'Pat Lee');
    assert.equal((await stu.call('POST', '/api/intros', { to: pat.id })).s, 200);
    assert.equal((await stu.call('POST', '/api/intros', { to: pat.id })).s, 400);
    const inc = await ind.call('GET', '/api/intros'); assert.equal(inc.j.incoming[0].email, null);
    await ind.call('POST', '/api/intros/' + inc.j.incoming[0].id, { decision: 'accepted' });
    assert.equal((await stu.call('GET', '/api/intros')).j.outgoing[0].email, 'pat@acme-test.com');
  });
  await t('report, moderator-level handling, hidden content disappears', async () => {
    assert.equal((await stu2.call('POST', '/api/reports', { type: 'solution', ref: sid, reason: 'Spam or off-topic' })).s, 200);
    assert.equal((await stu2.call('GET', '/api/staff/reports')).s, 403);
    const rs = await founder.call('GET', '/api/staff/reports'); const r = rs.j.reports.find(x => x.status === 'open');
    assert.equal((await founder.call('POST', '/api/staff/reports/' + r.id, { action: 'remove' })).s, 200);
    const b = await stu2.call('GET', '/api/board'); assert.equal(b.j.problems[0].solutions.length, 0);
  });
  await t('tickets: member creates, staff replies', async () => {
    assert.equal((await stu.call('POST', '/api/tickets', { cat: 'Verification', subject: 'Help', body: 'I need some help please' })).s, 200);
    const ts = await founder.call('GET', '/api/staff/tickets'); assert.equal((await founder.call('POST', '/api/staff/tickets/' + ts.j.tickets[0].id + '/reply', { body: 'On it' })).s, 200);
    assert.equal((await stu.call('GET', '/api/tickets')).j.tickets[0].replies.length, 1);
  });
  await t('staff roles are least-privilege; invite flow', async () => {
    assert.equal((await ind.call('GET', '/api/staff/team')).s, 403);
    assert.equal((await founder.call('POST', '/api/staff/team/invite', { email: 'mod@helper.example', role: 'moderator' })).s, 200);
    const m = new C(); await m.signup('mod@helper.example', { name: 'Mo Dee' });
    const me = await m.call('GET', '/api/me'); assert.equal(me.j.user.staffRole, 'moderator');
    assert.equal((await m.call('GET', '/api/staff/queue')).s, 200);
    assert.equal((await m.call('GET', '/api/staff/settings')).s, 403);
    assert.equal((await m.call('GET', '/api/staff/team')).s, 403);
    const team = await founder.call('GET', '/api/staff/team'); const fo = team.j.team.find(x => x.founder);
    assert.equal((await founder.call('POST', '/api/staff/team/' + fo.id + '/remove', {})).s, 403);
  });
  await t('settings: thresholds validated, flags, announcement, audit', async () => {
    assert.equal((await founder.call('PUT', '/api/staff/settings', { leagues: { silver: 30, gold: 20, platinum: 50 } })).s, 400);
    assert.equal((await founder.call('PUT', '/api/staff/settings', { leagues: { silver: 5, gold: 15, platinum: 40 }, flags: { ratings: false }, announcement: { text: 'Maintenance tonight', level: 'maintenance' } })).s, 200);
    assert.equal((await ind.call('PUT', '/api/solutions/' + sid + '/rating', { stars: 3 })).s, 403);
    assert.equal((await anon.call('GET', '/api/public')).j.announcement.text, 'Maintenance tonight');
    const au = await founder.call('GET', '/api/staff/audit'); assert.ok(au.j.audit.length > 3);
  });
  await t('suspended member is locked out immediately; logout works', async () => {
    const ms = await founder.call('GET', '/api/staff/members'); const bo = ms.j.members.find(x => x.name === 'Bo Chen');
    assert.equal((await founder.call('POST', '/api/staff/members/' + bo.id, { action: 'suspend' })).s, 200);
    assert.equal((await stu2.call('GET', '/api/board')).s, 401);
    await stu.call('POST', '/api/auth/logout', {}); assert.equal((await stu.call('GET', '/api/board')).s, 401);
  });
  await t('path traversal and unknown routes are safe', async () => {
    assert.equal((await fetch(base + '/..%2fserver.js')).status, 404); assert.equal((await fetch(base + '/%2e%2e/db.js')).status, 404);
    const idx = await fetch(base + '/'); assert.equal(idx.status, 200); assert.ok(idx.headers.get('content-security-policy'));
  });
  console.log(pass + ' passed'); server.close(); setTimeout(() => process.exit(process.exitCode || 0), 200);
})();
